#pragma once
#include "Nodo.h"
using namespace System;

public ref class ArbolBinario
{
private:
    Nodo^ raiz; // Ra�z del �rbol binario

public:
    ArbolBinario()
    {
        raiz = nullptr;
    }

    // M�todo para agregar un n�mero al �rbol
    void AgregarNumero(int numero)
    {
        raiz = AgregarNumeroRecursivo(raiz, numero);
    }

    // M�todo recursivo para agregar un n�mero en el �rbol
    Nodo^ AgregarNumeroRecursivo(Nodo^ nodo, int numero)
    {
        if (nodo == nullptr)
        {
            nodo = gcnew Nodo(numero);
        }
        else if (numero < nodo->valor)
        {
            nodo->hijoIzq = AgregarNumeroRecursivo(nodo->hijoIzq, numero);
        }
        else if (numero > nodo->valor)
        {
            nodo->hijoDer = AgregarNumeroRecursivo(nodo->hijoDer, numero);
        }

        return nodo;
    }

    // M�todo para mostrar el �rbol en orden (inorder traversal)
    void MostrarArbolEnOrden()
    {
        MostrarArbolEnOrdenRecursivo(raiz);
    }

    // M�todo recursivo para recorrer el �rbol en orden
    void MostrarArbolEnOrdenRecursivo(Nodo^ nodo)
    {
        if (nodo != nullptr)
        {
            MostrarArbolEnOrdenRecursivo(nodo->hijoIzq);
            Console::Write(nodo->valor + " ");
            MostrarArbolEnOrdenRecursivo(nodo->hijoDer);
        }
    }
};
/*

    // Crear un �rbol binario y agregar n�meros
    ArbolBinario^ arbol = gcnew ArbolBinario();
    arbol->AgregarNumero(50);
    arbol->AgregarNumero(30);
    arbol->AgregarNumero(70);
    arbol->AgregarNumero(20);
    arbol->AgregarNumero(40);
    arbol->MostrarArbolEnOrden(); // Salida: 20 30 40 50 70

    // Crear un grafo con 5 nodos
    Grafo^ grafo = gcnew Grafo(5);
    grafo->AgregarArista(0, 1);
    grafo->AgregarArista(0, 2);
    grafo->AgregarArista(1, 3);
    grafo->AgregarArista(2, 4);
    grafo->MostrarGrafo();

*/