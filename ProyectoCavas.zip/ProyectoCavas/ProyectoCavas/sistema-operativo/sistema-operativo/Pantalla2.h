#pragma once
#include "Cuenta.h"


namespace sistemaoperativo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Pantalla2
	/// </summary>
	public ref class Pantalla2 : public System::Windows::Forms::Form
	{
	public:
		Pantalla2(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Pantalla2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel4;
	private: System::Windows::Forms::PictureBox^ pictureBox5;
	private: System::Windows::Forms::PictureBox^ pictureBox4;
	private: System::Windows::Forms::PictureBox^ pictureBox3;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::PictureBox^ pictureBox7;
	private: System::Windows::Forms::PictureBox^ pictureBox6;



	private: System::Windows::Forms::Panel^ panel5;
	private: System::Windows::Forms::Label^ label3;



	private: System::Windows::Forms::Panel^ panel9;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Panel^ panel8;
	private: System::Windows::Forms::Panel^ panel10;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::Panel^ panel11;
	private: System::Windows::Forms::Label^ label14;
	private: System::Windows::Forms::Panel^ panel12;
	private: System::Windows::Forms::Label^ label15;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Panel^ panel7;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Panel^ panel6;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Panel^ panel20;
	private: System::Windows::Forms::Panel^ panel21;
	private: System::Windows::Forms::Label^ label23;
	private: System::Windows::Forms::Panel^ panel22;
	private: System::Windows::Forms::Label^ label24;
	private: System::Windows::Forms::Panel^ panel23;
	private: System::Windows::Forms::Label^ label25;
	private: System::Windows::Forms::Label^ label26;
	private: System::Windows::Forms::Panel^ panel13;
	private: System::Windows::Forms::Panel^ panel14;
	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::Panel^ panel15;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Panel^ panel16;
	private: System::Windows::Forms::Label^ label18;
	private: System::Windows::Forms::Label^ label19;
	private: System::Windows::Forms::Panel^ panel24;
	private: System::Windows::Forms::Panel^ panel25;
	private: System::Windows::Forms::Label^ label27;
	private: System::Windows::Forms::Panel^ panel26;
	private: System::Windows::Forms::Label^ label28;
	private: System::Windows::Forms::Panel^ panel27;
	private: System::Windows::Forms::Label^ label29;
	private: System::Windows::Forms::Label^ label30;
	private: System::Windows::Forms::Panel^ panel28;
	private: System::Windows::Forms::Label^ label31;
	private: System::Windows::Forms::Panel^ panel17;
	private: System::Windows::Forms::Label^ label20;
	private: System::Windows::Forms::Panel^ panel29;
	private: System::Windows::Forms::Label^ label32;
	private: System::Windows::Forms::Panel^ panel30;
	private: System::Windows::Forms::Label^ label33;
	private: System::Windows::Forms::Panel^ panel18;
	private: System::Windows::Forms::Label^ label21;
	private: System::Windows::Forms::Panel^ panel31;
	private: System::Windows::Forms::Label^ label34;
	private: System::Windows::Forms::Panel^ panel19;
	private: System::Windows::Forms::Label^ label22;
	private: System::Windows::Forms::Panel^ panel32;
	private: System::Windows::Forms::Label^ label35;
	private: System::Windows::Forms::Panel^ panel33;
	private: System::Windows::Forms::Label^ label36;
	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Pantalla2::typeid));
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->panel9 = (gcnew System::Windows::Forms::Panel());
			this->pictureBox7 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox6 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->panel20 = (gcnew System::Windows::Forms::Panel());
			this->panel21 = (gcnew System::Windows::Forms::Panel());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->panel22 = (gcnew System::Windows::Forms::Panel());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->panel23 = (gcnew System::Windows::Forms::Panel());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->panel13 = (gcnew System::Windows::Forms::Panel());
			this->panel14 = (gcnew System::Windows::Forms::Panel());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->panel15 = (gcnew System::Windows::Forms::Panel());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->panel16 = (gcnew System::Windows::Forms::Panel());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->panel24 = (gcnew System::Windows::Forms::Panel());
			this->panel25 = (gcnew System::Windows::Forms::Panel());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->panel26 = (gcnew System::Windows::Forms::Panel());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->panel27 = (gcnew System::Windows::Forms::Panel());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->panel8 = (gcnew System::Windows::Forms::Panel());
			this->panel10 = (gcnew System::Windows::Forms::Panel());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->panel11 = (gcnew System::Windows::Forms::Panel());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->panel12 = (gcnew System::Windows::Forms::Panel());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->panel28 = (gcnew System::Windows::Forms::Panel());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->panel17 = (gcnew System::Windows::Forms::Panel());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->panel29 = (gcnew System::Windows::Forms::Panel());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->panel7 = (gcnew System::Windows::Forms::Panel());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->panel30 = (gcnew System::Windows::Forms::Panel());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->panel18 = (gcnew System::Windows::Forms::Panel());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->panel31 = (gcnew System::Windows::Forms::Panel());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->panel19 = (gcnew System::Windows::Forms::Panel());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->panel32 = (gcnew System::Windows::Forms::Panel());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->panel33 = (gcnew System::Windows::Forms::Panel());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->panel1->SuspendLayout();
			this->panel9->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox7))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->panel2->SuspendLayout();
			this->panel3->SuspendLayout();
			this->panel4->SuspendLayout();
			this->panel20->SuspendLayout();
			this->panel21->SuspendLayout();
			this->panel22->SuspendLayout();
			this->panel23->SuspendLayout();
			this->panel13->SuspendLayout();
			this->panel14->SuspendLayout();
			this->panel15->SuspendLayout();
			this->panel16->SuspendLayout();
			this->panel24->SuspendLayout();
			this->panel25->SuspendLayout();
			this->panel26->SuspendLayout();
			this->panel27->SuspendLayout();
			this->panel8->SuspendLayout();
			this->panel10->SuspendLayout();
			this->panel11->SuspendLayout();
			this->panel12->SuspendLayout();
			this->panel28->SuspendLayout();
			this->panel17->SuspendLayout();
			this->panel29->SuspendLayout();
			this->panel7->SuspendLayout();
			this->panel30->SuspendLayout();
			this->panel18->SuspendLayout();
			this->panel31->SuspendLayout();
			this->panel19->SuspendLayout();
			this->panel32->SuspendLayout();
			this->panel33->SuspendLayout();
			this->panel6->SuspendLayout();
			this->panel5->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left));
			this->panel1->BackColor = System::Drawing::Color::MidnightBlue;
			this->panel1->Controls->Add(this->label12);
			this->panel1->Controls->Add(this->label11);
			this->panel1->Controls->Add(this->label10);
			this->panel1->Controls->Add(this->label9);
			this->panel1->Controls->Add(this->label8);
			this->panel1->Controls->Add(this->label7);
			this->panel1->Controls->Add(this->panel9);
			this->panel1->Controls->Add(this->pictureBox6);
			this->panel1->Controls->Add(this->pictureBox5);
			this->panel1->Controls->Add(this->pictureBox4);
			this->panel1->Controls->Add(this->pictureBox3);
			this->panel1->Controls->Add(this->pictureBox2);
			this->panel1->Controls->Add(this->pictureBox1);
			this->panel1->Controls->Add(this->panel2);
			this->panel1->Location = System::Drawing::Point(-1, -3);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(179, 682);
			this->panel1->TabIndex = 0;
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label12->Location = System::Drawing::Point(71, 561);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(46, 16);
			this->label12->TabIndex = 14;
			this->label12->Text = L"Ayuda";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label11->Location = System::Drawing::Point(71, 489);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(56, 16);
			this->label11->TabIndex = 13;
			this->label11->Text = L"Historial";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label10->Location = System::Drawing::Point(43, 420);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(119, 16);
			this->label10->TabIndex = 12;
			this->label10->Text = L"Badeja de entrada";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label9->Location = System::Drawing::Point(63, 339);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(73, 16);
			this->label9->TabIndex = 11;
			this->label9->Text = L"Calendario";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label8->Location = System::Drawing::Point(71, 253);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(49, 16);
			this->label8->TabIndex = 10;
			this->label8->Text = L"Cursos";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label7->Location = System::Drawing::Point(71, 178);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(49, 16);
			this->label7->TabIndex = 9;
			this->label7->Text = L"Cuenta";
			// 
			// panel9
			// 
			this->panel9->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->panel9->Controls->Add(this->pictureBox7);
			this->panel9->Location = System::Drawing::Point(4, 580);
			this->panel9->Name = L"panel9";
			this->panel9->Size = System::Drawing::Size(175, 93);
			this->panel9->TabIndex = 8;
			// 
			// pictureBox7
			// 
			this->pictureBox7->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->pictureBox7->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox7.Image")));
			this->pictureBox7->Location = System::Drawing::Point(62, 18);
			this->pictureBox7->Name = L"pictureBox7";
			this->pictureBox7->Size = System::Drawing::Size(60, 50);
			this->pictureBox7->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox7->TabIndex = 7;
			this->pictureBox7->TabStop = false;
			this->pictureBox7->Click += gcnew System::EventHandler(this, &Pantalla2::pictureBox7_Click);
			// 
			// pictureBox6
			// 
			this->pictureBox6->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox6.Image")));
			this->pictureBox6->Location = System::Drawing::Point(66, 508);
			this->pictureBox6->Name = L"pictureBox6";
			this->pictureBox6->Size = System::Drawing::Size(60, 50);
			this->pictureBox6->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox6->TabIndex = 6;
			this->pictureBox6->TabStop = false;
			// 
			// pictureBox5
			// 
			this->pictureBox5->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox5.Image")));
			this->pictureBox5->Location = System::Drawing::Point(66, 439);
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->Size = System::Drawing::Size(60, 50);
			this->pictureBox5->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox5->TabIndex = 5;
			this->pictureBox5->TabStop = false;
			// 
			// pictureBox4
			// 
			this->pictureBox4->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox4.Image")));
			this->pictureBox4->Location = System::Drawing::Point(66, 366);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(60, 50);
			this->pictureBox4->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox4->TabIndex = 4;
			this->pictureBox4->TabStop = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox3.Image")));
			this->pictureBox3->Location = System::Drawing::Point(66, 286);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(60, 50);
			this->pictureBox3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox3->TabIndex = 3;
			this->pictureBox3->TabStop = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(66, 200);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(60, 50);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox2->TabIndex = 2;
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(71, 125);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(49, 50);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 1;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &Pantalla2::pictureBox1_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::Crimson;
			this->panel2->Controls->Add(this->label2);
			this->panel2->Location = System::Drawing::Point(0, 0);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(179, 106);
			this->panel2->TabIndex = 0;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Dubai", 22.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->label2->Location = System::Drawing::Point(63, 29);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(52, 63);
			this->label2->TabIndex = 0;
			this->label2->Text = L"U";
			// 
			// panel3
			// 
			this->panel3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->panel3->Controls->Add(this->label1);
			this->panel3->Location = System::Drawing::Point(176, 1);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(1035, 100);
			this->panel3->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 24, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(22, 30);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(774, 46);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tablero                                                   ";
			// 
			// panel4
			// 
			this->panel4->Controls->Add(this->panel20);
			this->panel4->Controls->Add(this->panel13);
			this->panel4->Controls->Add(this->panel24);
			this->panel4->Controls->Add(this->panel8);
			this->panel4->Controls->Add(this->panel28);
			this->panel4->Controls->Add(this->panel17);
			this->panel4->Controls->Add(this->panel29);
			this->panel4->Controls->Add(this->panel7);
			this->panel4->Controls->Add(this->panel30);
			this->panel4->Controls->Add(this->panel18);
			this->panel4->Controls->Add(this->panel31);
			this->panel4->Controls->Add(this->panel19);
			this->panel4->Controls->Add(this->panel32);
			this->panel4->Controls->Add(this->panel33);
			this->panel4->Controls->Add(this->panel6);
			this->panel4->Controls->Add(this->panel5);
			this->panel4->Location = System::Drawing::Point(184, 107);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(1027, 564);
			this->panel4->TabIndex = 2;
			this->panel4->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Pantalla2::panel4_Paint);
			// 
			// panel20
			// 
			this->panel20->BackColor = System::Drawing::Color::Chocolate;
			this->panel20->Controls->Add(this->panel21);
			this->panel20->Controls->Add(this->panel22);
			this->panel20->Controls->Add(this->panel23);
			this->panel20->Controls->Add(this->label26);
			this->panel20->Location = System::Drawing::Point(767, 422);
			this->panel20->Name = L"panel20";
			this->panel20->Size = System::Drawing::Size(200, 100);
			this->panel20->TabIndex = 16;
			// 
			// panel21
			// 
			this->panel21->BackColor = System::Drawing::Color::Chocolate;
			this->panel21->Controls->Add(this->label23);
			this->panel21->Location = System::Drawing::Point(477, 0);
			this->panel21->Name = L"panel21";
			this->panel21->Size = System::Drawing::Size(200, 100);
			this->panel21->TabIndex = 4;
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(80, 33);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(50, 16);
			this->label23->TabIndex = 3;
			this->label23->Text = L"CLASE";
			// 
			// panel22
			// 
			this->panel22->BackColor = System::Drawing::Color::Chocolate;
			this->panel22->Controls->Add(this->label24);
			this->panel22->Location = System::Drawing::Point(239, 0);
			this->panel22->Name = L"panel22";
			this->panel22->Size = System::Drawing::Size(200, 100);
			this->panel22->TabIndex = 5;
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(68, 33);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(50, 16);
			this->label24->TabIndex = 2;
			this->label24->Text = L"CLASE";
			// 
			// panel23
			// 
			this->panel23->BackColor = System::Drawing::Color::Chocolate;
			this->panel23->Controls->Add(this->label25);
			this->panel23->Location = System::Drawing::Point(0, 0);
			this->panel23->Name = L"panel23";
			this->panel23->Size = System::Drawing::Size(200, 100);
			this->panel23->TabIndex = 6;
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(72, 33);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(50, 16);
			this->label25->TabIndex = 1;
			this->label25->Text = L"CLASE";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(80, 33);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(50, 16);
			this->label26->TabIndex = 3;
			this->label26->Text = L"CLASE";
			// 
			// panel13
			// 
			this->panel13->BackColor = System::Drawing::Color::Chocolate;
			this->panel13->Controls->Add(this->panel14);
			this->panel13->Controls->Add(this->panel15);
			this->panel13->Controls->Add(this->panel16);
			this->panel13->Controls->Add(this->label19);
			this->panel13->Location = System::Drawing::Point(767, 167);
			this->panel13->Name = L"panel13";
			this->panel13->Size = System::Drawing::Size(200, 100);
			this->panel13->TabIndex = 8;
			// 
			// panel14
			// 
			this->panel14->BackColor = System::Drawing::Color::Chocolate;
			this->panel14->Controls->Add(this->label16);
			this->panel14->Location = System::Drawing::Point(477, 0);
			this->panel14->Name = L"panel14";
			this->panel14->Size = System::Drawing::Size(200, 100);
			this->panel14->TabIndex = 4;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(80, 33);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(50, 16);
			this->label16->TabIndex = 3;
			this->label16->Text = L"CLASE";
			// 
			// panel15
			// 
			this->panel15->BackColor = System::Drawing::Color::Chocolate;
			this->panel15->Controls->Add(this->label17);
			this->panel15->Location = System::Drawing::Point(239, 0);
			this->panel15->Name = L"panel15";
			this->panel15->Size = System::Drawing::Size(200, 100);
			this->panel15->TabIndex = 5;
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(68, 33);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(50, 16);
			this->label17->TabIndex = 2;
			this->label17->Text = L"CLASE";
			// 
			// panel16
			// 
			this->panel16->BackColor = System::Drawing::Color::Chocolate;
			this->panel16->Controls->Add(this->label18);
			this->panel16->Location = System::Drawing::Point(0, 0);
			this->panel16->Name = L"panel16";
			this->panel16->Size = System::Drawing::Size(200, 100);
			this->panel16->TabIndex = 6;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(72, 33);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(50, 16);
			this->label18->TabIndex = 1;
			this->label18->Text = L"CLASE";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(80, 33);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(50, 16);
			this->label19->TabIndex = 3;
			this->label19->Text = L"CLASE";
			// 
			// panel24
			// 
			this->panel24->BackColor = System::Drawing::Color::Chocolate;
			this->panel24->Controls->Add(this->panel25);
			this->panel24->Controls->Add(this->panel26);
			this->panel24->Controls->Add(this->panel27);
			this->panel24->Controls->Add(this->label30);
			this->panel24->Location = System::Drawing::Point(767, 295);
			this->panel24->Name = L"panel24";
			this->panel24->Size = System::Drawing::Size(200, 100);
			this->panel24->TabIndex = 12;
			// 
			// panel25
			// 
			this->panel25->BackColor = System::Drawing::Color::Chocolate;
			this->panel25->Controls->Add(this->label27);
			this->panel25->Location = System::Drawing::Point(477, 0);
			this->panel25->Name = L"panel25";
			this->panel25->Size = System::Drawing::Size(200, 100);
			this->panel25->TabIndex = 4;
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(80, 33);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(50, 16);
			this->label27->TabIndex = 3;
			this->label27->Text = L"CLASE";
			// 
			// panel26
			// 
			this->panel26->BackColor = System::Drawing::Color::Chocolate;
			this->panel26->Controls->Add(this->label28);
			this->panel26->Location = System::Drawing::Point(239, 0);
			this->panel26->Name = L"panel26";
			this->panel26->Size = System::Drawing::Size(200, 100);
			this->panel26->TabIndex = 5;
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(68, 33);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(50, 16);
			this->label28->TabIndex = 2;
			this->label28->Text = L"CLASE";
			// 
			// panel27
			// 
			this->panel27->BackColor = System::Drawing::Color::Chocolate;
			this->panel27->Controls->Add(this->label29);
			this->panel27->Location = System::Drawing::Point(0, 0);
			this->panel27->Name = L"panel27";
			this->panel27->Size = System::Drawing::Size(200, 100);
			this->panel27->TabIndex = 6;
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(72, 33);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(50, 16);
			this->label29->TabIndex = 1;
			this->label29->Text = L"CLASE";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(80, 33);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(50, 16);
			this->label30->TabIndex = 3;
			this->label30->Text = L"CLASE";
			// 
			// panel8
			// 
			this->panel8->BackColor = System::Drawing::Color::Chocolate;
			this->panel8->Controls->Add(this->panel10);
			this->panel8->Controls->Add(this->panel11);
			this->panel8->Controls->Add(this->panel12);
			this->panel8->Controls->Add(this->label6);
			this->panel8->Location = System::Drawing::Point(767, 40);
			this->panel8->Name = L"panel8";
			this->panel8->Size = System::Drawing::Size(200, 100);
			this->panel8->TabIndex = 1;
			// 
			// panel10
			// 
			this->panel10->BackColor = System::Drawing::Color::Chocolate;
			this->panel10->Controls->Add(this->label13);
			this->panel10->Location = System::Drawing::Point(477, 0);
			this->panel10->Name = L"panel10";
			this->panel10->Size = System::Drawing::Size(200, 100);
			this->panel10->TabIndex = 4;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(80, 33);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(50, 16);
			this->label13->TabIndex = 3;
			this->label13->Text = L"CLASE";
			// 
			// panel11
			// 
			this->panel11->BackColor = System::Drawing::Color::Chocolate;
			this->panel11->Controls->Add(this->label14);
			this->panel11->Location = System::Drawing::Point(239, 0);
			this->panel11->Name = L"panel11";
			this->panel11->Size = System::Drawing::Size(200, 100);
			this->panel11->TabIndex = 5;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(68, 33);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(50, 16);
			this->label14->TabIndex = 2;
			this->label14->Text = L"CLASE";
			// 
			// panel12
			// 
			this->panel12->BackColor = System::Drawing::Color::Chocolate;
			this->panel12->Controls->Add(this->label15);
			this->panel12->Location = System::Drawing::Point(0, 0);
			this->panel12->Name = L"panel12";
			this->panel12->Size = System::Drawing::Size(200, 100);
			this->panel12->TabIndex = 6;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(72, 33);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(50, 16);
			this->label15->TabIndex = 1;
			this->label15->Text = L"CLASE";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(80, 33);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(50, 16);
			this->label6->TabIndex = 3;
			this->label6->Text = L"CLASE";
			// 
			// panel28
			// 
			this->panel28->BackColor = System::Drawing::Color::Chocolate;
			this->panel28->Controls->Add(this->label31);
			this->panel28->Location = System::Drawing::Point(529, 422);
			this->panel28->Name = L"panel28";
			this->panel28->Size = System::Drawing::Size(200, 100);
			this->panel28->TabIndex = 17;
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(68, 33);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(50, 16);
			this->label31->TabIndex = 2;
			this->label31->Text = L"CLASE";
			// 
			// panel17
			// 
			this->panel17->BackColor = System::Drawing::Color::Chocolate;
			this->panel17->Controls->Add(this->label20);
			this->panel17->Location = System::Drawing::Point(529, 167);
			this->panel17->Name = L"panel17";
			this->panel17->Size = System::Drawing::Size(200, 100);
			this->panel17->TabIndex = 9;
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(68, 33);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(50, 16);
			this->label20->TabIndex = 2;
			this->label20->Text = L"CLASE";
			// 
			// panel29
			// 
			this->panel29->BackColor = System::Drawing::Color::Chocolate;
			this->panel29->Controls->Add(this->label32);
			this->panel29->Location = System::Drawing::Point(529, 295);
			this->panel29->Name = L"panel29";
			this->panel29->Size = System::Drawing::Size(200, 100);
			this->panel29->TabIndex = 13;
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(68, 33);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(50, 16);
			this->label32->TabIndex = 2;
			this->label32->Text = L"CLASE";
			// 
			// panel7
			// 
			this->panel7->BackColor = System::Drawing::Color::Chocolate;
			this->panel7->Controls->Add(this->label5);
			this->panel7->Location = System::Drawing::Point(529, 40);
			this->panel7->Name = L"panel7";
			this->panel7->Size = System::Drawing::Size(200, 100);
			this->panel7->TabIndex = 1;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(68, 33);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(50, 16);
			this->label5->TabIndex = 2;
			this->label5->Text = L"CLASE";
			// 
			// panel30
			// 
			this->panel30->BackColor = System::Drawing::Color::Chocolate;
			this->panel30->Controls->Add(this->label33);
			this->panel30->Location = System::Drawing::Point(290, 422);
			this->panel30->Name = L"panel30";
			this->panel30->Size = System::Drawing::Size(200, 100);
			this->panel30->TabIndex = 18;
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(72, 33);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(50, 16);
			this->label33->TabIndex = 1;
			this->label33->Text = L"CLASE";
			// 
			// panel18
			// 
			this->panel18->BackColor = System::Drawing::Color::Chocolate;
			this->panel18->Controls->Add(this->label21);
			this->panel18->Location = System::Drawing::Point(290, 167);
			this->panel18->Name = L"panel18";
			this->panel18->Size = System::Drawing::Size(200, 100);
			this->panel18->TabIndex = 10;
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(72, 33);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(50, 16);
			this->label21->TabIndex = 1;
			this->label21->Text = L"CLASE";
			// 
			// panel31
			// 
			this->panel31->BackColor = System::Drawing::Color::Chocolate;
			this->panel31->Controls->Add(this->label34);
			this->panel31->Location = System::Drawing::Point(60, 422);
			this->panel31->Name = L"panel31";
			this->panel31->Size = System::Drawing::Size(200, 100);
			this->panel31->TabIndex = 15;
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(74, 33);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(50, 16);
			this->label34->TabIndex = 0;
			this->label34->Text = L"CLASE";
			// 
			// panel19
			// 
			this->panel19->BackColor = System::Drawing::Color::Chocolate;
			this->panel19->Controls->Add(this->label22);
			this->panel19->Location = System::Drawing::Point(60, 167);
			this->panel19->Name = L"panel19";
			this->panel19->Size = System::Drawing::Size(200, 100);
			this->panel19->TabIndex = 7;
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(74, 33);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(50, 16);
			this->label22->TabIndex = 0;
			this->label22->Text = L"CLASE";
			// 
			// panel32
			// 
			this->panel32->BackColor = System::Drawing::Color::Chocolate;
			this->panel32->Controls->Add(this->label35);
			this->panel32->Location = System::Drawing::Point(290, 295);
			this->panel32->Name = L"panel32";
			this->panel32->Size = System::Drawing::Size(200, 100);
			this->panel32->TabIndex = 14;
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(72, 33);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(50, 16);
			this->label35->TabIndex = 1;
			this->label35->Text = L"CLASE";
			// 
			// panel33
			// 
			this->panel33->BackColor = System::Drawing::Color::Chocolate;
			this->panel33->Controls->Add(this->label36);
			this->panel33->Location = System::Drawing::Point(60, 295);
			this->panel33->Name = L"panel33";
			this->panel33->Size = System::Drawing::Size(200, 100);
			this->panel33->TabIndex = 11;
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(74, 33);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(50, 16);
			this->label36->TabIndex = 0;
			this->label36->Text = L"CLASE";
			// 
			// panel6
			// 
			this->panel6->BackColor = System::Drawing::Color::Chocolate;
			this->panel6->Controls->Add(this->label4);
			this->panel6->Location = System::Drawing::Point(290, 40);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(200, 100);
			this->panel6->TabIndex = 1;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(72, 33);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(50, 16);
			this->label4->TabIndex = 1;
			this->label4->Text = L"CLASE";
			// 
			// panel5
			// 
			this->panel5->BackColor = System::Drawing::Color::Chocolate;
			this->panel5->Controls->Add(this->label3);
			this->panel5->Location = System::Drawing::Point(60, 40);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(200, 100);
			this->panel5->TabIndex = 0;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(74, 33);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(50, 16);
			this->label3->TabIndex = 0;
			this->label3->Text = L"CLASE";
			// 
			// Pantalla2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1212, 675);
			this->Controls->Add(this->panel4);
			this->Controls->Add(this->panel3);
			this->Controls->Add(this->panel1);
			this->Name = L"Pantalla2";
			this->Text = L"Pantalla2";
			this->Load += gcnew System::EventHandler(this, &Pantalla2::Pantalla2_Load);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel9->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox7))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->panel4->ResumeLayout(false);
			this->panel20->ResumeLayout(false);
			this->panel20->PerformLayout();
			this->panel21->ResumeLayout(false);
			this->panel21->PerformLayout();
			this->panel22->ResumeLayout(false);
			this->panel22->PerformLayout();
			this->panel23->ResumeLayout(false);
			this->panel23->PerformLayout();
			this->panel13->ResumeLayout(false);
			this->panel13->PerformLayout();
			this->panel14->ResumeLayout(false);
			this->panel14->PerformLayout();
			this->panel15->ResumeLayout(false);
			this->panel15->PerformLayout();
			this->panel16->ResumeLayout(false);
			this->panel16->PerformLayout();
			this->panel24->ResumeLayout(false);
			this->panel24->PerformLayout();
			this->panel25->ResumeLayout(false);
			this->panel25->PerformLayout();
			this->panel26->ResumeLayout(false);
			this->panel26->PerformLayout();
			this->panel27->ResumeLayout(false);
			this->panel27->PerformLayout();
			this->panel8->ResumeLayout(false);
			this->panel8->PerformLayout();
			this->panel10->ResumeLayout(false);
			this->panel10->PerformLayout();
			this->panel11->ResumeLayout(false);
			this->panel11->PerformLayout();
			this->panel12->ResumeLayout(false);
			this->panel12->PerformLayout();
			this->panel28->ResumeLayout(false);
			this->panel28->PerformLayout();
			this->panel17->ResumeLayout(false);
			this->panel17->PerformLayout();
			this->panel29->ResumeLayout(false);
			this->panel29->PerformLayout();
			this->panel7->ResumeLayout(false);
			this->panel7->PerformLayout();
			this->panel30->ResumeLayout(false);
			this->panel30->PerformLayout();
			this->panel18->ResumeLayout(false);
			this->panel18->PerformLayout();
			this->panel31->ResumeLayout(false);
			this->panel31->PerformLayout();
			this->panel19->ResumeLayout(false);
			this->panel19->PerformLayout();
			this->panel32->ResumeLayout(false);
			this->panel32->PerformLayout();
			this->panel33->ResumeLayout(false);
			this->panel33->PerformLayout();
			this->panel6->ResumeLayout(false);
			this->panel6->PerformLayout();
			this->panel5->ResumeLayout(false);
			this->panel5->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void pictureBox7_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();

	
	}
		



private: System::Void panel4_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	//aqui dentro van aparecer las clases que son asignadas en registro
}
private: System::Void Pantalla2_Load(System::Object^ sender, System::EventArgs^ e) {

}
private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
	Cuenta^ form = gcnew Cuenta();
	form->Show();
}
};
}
