#pragma once
using namespace System;
using namespace System::Data;
using namespace System::Data::OleDb;
using namespace System::Windows::Forms;


// Clase que representa un Maestro
public ref class Maestro {
public:
    int IdMaestro;        
    String^ Nombre;        // Nombre del maestro
    String^ Profesion;     // Profesi�n del maestro
    String^ Rol;           // Rol del maestro
    String^ Sueldo;        // Sueldo del maestro (modificado de String a String^)
    String^ Cuenta;        // Cuenta de acceso
    String^ Contrase�a;    // Contrase�a de acceso
};

// Clase para gestionar la conexi�n y operaciones con la tabla Maestros
ref class ConexionDBMaestros
{
public:
    static String^ connectionString =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Data\\Data.accdb";

    // M�todo para insertar un nuevo maestro
    static bool InsertarMaestro(String^ nombre, String^ profesion, String^ rol, String^ sueldo, String^ cuenta, String^ contrase�a)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            // Consulta SQL para insertar un nuevo maestro
            String^ query = "INSERT INTO Maestros (nombre, profesion, rol, sueldo, cuenta, contrase�a) VALUES (?, ?, ?, ?, ?, ?)";

            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

            // Agregar los par�metros para evitar inyecci�n SQL
            cmd->Parameters->AddWithValue("?", nombre);
            cmd->Parameters->AddWithValue("?", profesion);
            cmd->Parameters->AddWithValue("?", rol);  // Agregar Rol
            cmd->Parameters->AddWithValue("?", sueldo);
            cmd->Parameters->AddWithValue("?", cuenta);
            cmd->Parameters->AddWithValue("?", contrase�a);

            // Ejecutar la consulta
            int filasAfectadas = cmd->ExecuteNonQuery();
            conn->Close();

            if (filasAfectadas > 0) {
                MessageBox::Show("El maestro ha sido insertado exitosamente.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
                return true; // Retorna true si se insert� correctamente
            }
            else {
                MessageBox::Show("No se insertaron registros. Por favor, intente nuevamente.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                return false;
            }

        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false; // Retorna false si hubo un error
        }
    }
    

    // M�todo para editar un maestro por su ID
    static bool EditarMaestro(int idMaestro, String^ nuevoNombre, String^ nuevaProfesion, String^ nuevoRol, String^ nuevoSueldo, String^ nuevaCuenta, String^ nuevaContrase�a)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            String^ query = "UPDATE Maestros SET nombre = ?, profesion = ?, rol = ?, sueldo = ?, cuenta = ?, contrase�a = ? WHERE idMaestro = ?";

            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

            cmd->Parameters->AddWithValue("?", nuevoNombre);
            cmd->Parameters->AddWithValue("?", nuevaProfesion);
            cmd->Parameters->AddWithValue("?", nuevoRol);  // Agregar Rol
            cmd->Parameters->AddWithValue("?", nuevoSueldo);
            cmd->Parameters->AddWithValue("?", nuevaCuenta);
            cmd->Parameters->AddWithValue("?", nuevaContrase�a);
            cmd->Parameters->AddWithValue("?", idMaestro);

            int filasAfectadas = cmd->ExecuteNonQuery();

            conn->Close();

            return filasAfectadas > 0;
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false;
        }
    }

    // M�todo para eliminar un maestro por su ID
    static bool EliminarMaestro(int idMaestro)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            String^ query = "DELETE FROM Maestros WHERE idMaestro = ?";

            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);
            cmd->Parameters->AddWithValue("?", idMaestro);

            int filasAfectadas = cmd->ExecuteNonQuery();

            conn->Close();

            return filasAfectadas > 0;
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false;
        }
    }

    // M�todo para obtener un maestro por su ID
    static Maestro^ BuscarMaestroPorId(int idMaestro)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            String^ query = "SELECT nombre, profesion, rol, sueldo, cuenta, contrase�a FROM Maestros WHERE idMaestro = ?";
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);
            cmd->Parameters->AddWithValue("?", idMaestro);

            OleDbDataReader^ reader = cmd->ExecuteReader();

            if (reader->Read()) // Si encuentra el maestro
            {
                Maestro^ maestro = gcnew Maestro();
                maestro->IdMaestro = idMaestro;
                maestro->Nombre = reader->GetString(0); // Primer columna: nombre
                maestro->Profesion = reader->GetString(1); // Segunda columna: profesi�n
                maestro->Rol = reader->GetString(2);  // Tercer columna: rol
                maestro->Sueldo = reader->GetString(3); // Cuarta columna: sueldo
                maestro->Cuenta = reader->GetString(4); // Quinta columna: cuenta
                maestro->Contrase�a = reader->GetString(5); // Sexta columna: contrase�a

                conn->Close();
                return maestro; // Retorna el objeto Maestro
            }

            conn->Close();
            return nullptr; // Si no encuentra el maestro, retorna nullptr
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return nullptr;
        }
    }

    // M�todo para obtener todos los maestros
    static DataTable^ ObtenerMaestros()
    {
        DataTable^ dt = gcnew DataTable(); // Definir dt antes de su uso
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            String^ query = "SELECT * FROM Maestros";
            OleDbDataAdapter^ adapter = gcnew OleDbDataAdapter(query, conn);
            adapter->Fill(dt);

            conn->Close();
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
        }
        return dt;
    }

    // M�todo para llenar un ComboBox con los nombres de los maestros
    static void LlenarComboBoxMaestros(ComboBox^ comboBox)
    {
        try
        {
            // Definir la conexi�n a la base de datos
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            // Consulta SQL
            String^ query = "SELECT cuenta FROM Maestros";
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

            // Limpiar los elementos actuales del ComboBox
            comboBox->Items->Clear();

            // Ejecutar la consulta y llenar el ComboBox con los resultados
            OleDbDataReader^ reader = cmd->ExecuteReader();
            int count = 0;

            while (reader->Read())
            {
                String^ cuenta = reader["cuenta"]->ToString();
                comboBox->Items->Add(cuenta);
                count++;
            }

            reader->Close();

            // Mostrar mensaje si no se encontraron maestros
            if (count == 0)
            {
                MessageBox::Show("No se encontraron maestros.", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
            }

            conn->Close();
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            MessageBox::Show("Ocurri� un error al intentar obtener los maestros.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
        }
    }


};
