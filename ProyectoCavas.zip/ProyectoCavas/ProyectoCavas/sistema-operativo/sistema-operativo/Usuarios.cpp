#pragma once
using namespace System;
using namespace System::Collections::Generic;

public ref class Usuarios
{
private:
    static List<Usuarios^>^ listaUsuarios = gcnew List<Usuarios^>(); // Initialize the list here
    String^ nombre;
    String^ contrasena;
    String^ rol;

public:
    // Constructor
    Usuarios(String^ nombre, String^ contrasena, String^ rol)
    {
        this->nombre = nombre;
        this->contrasena = contrasena;
        this->rol = rol;
    }

    // Static method to add a user to the list
    static void AgregarUsuario(String^ nombre, String^ contrasena, String^ rol)
    {
        Usuarios^ nuevoUsuario = gcnew Usuarios(nombre, contrasena, rol);
        listaUsuarios->Add(nuevoUsuario);
    }

    // Static method to delete a user by name
    static bool EliminarUsuario(String^ nombre)
    {
        for (int i = 0; i < listaUsuarios->Count; i++)
        {
            if (listaUsuarios[i]->nombre == nombre)
            {
                listaUsuarios->RemoveAt(i);
                return true; // User deleted successfully
            }
        }
        return false; // User not found
    }

    // Static method to verify if a username and password match
    static bool VerificarUsuario(String^ nombre, String^ contrasena)
    {
        for each (Usuarios ^ usuario in listaUsuarios)
        {
            if (usuario->nombre == nombre && usuario->contrasena == contrasena)
            {
                return true; // Username and password match
            }
        }
        return false; // No match found
    }

    // Static method to add a default user
    static void AgregarUsuarioPorDefecto()
    {
        AgregarUsuario("admin", "1234", "admin");
    }
};
