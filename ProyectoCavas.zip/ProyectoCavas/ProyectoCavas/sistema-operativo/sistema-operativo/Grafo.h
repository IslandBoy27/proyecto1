#pragma once
#include "Nodo.h"
using namespace System;

public ref class Grafo
{
private:
    array<Nodo^>^ nodos; // Array para almacenar los nodos del grafo
    int cantidadNodos; // Cantidad de nodos en el grafo

public:
    Grafo(int numNodos)
    {
        cantidadNodos = numNodos;
        nodos = gcnew array<Nodo^>(cantidadNodos);

        // Inicializar los nodos
        for (int i = 0; i < cantidadNodos; i++)
        {
            nodos[i] = gcnew Nodo(i); // El valor del nodo ser� el �ndice
        }
    }

    // M�todo para agregar una arista entre dos nodos
    void AgregarArista(int nodoOrigen, int nodoDestino)
    {
        Nodo^ nuevoNodo = gcnew Nodo(nodoDestino);
        nuevoNodo->siguiente = nodos[nodoOrigen]->siguiente;
        nodos[nodoOrigen]->siguiente = nuevoNodo;
    }

    // Mostrar las conexiones de los nodos
    void MostrarGrafo()
    {
        for (int i = 0; i < cantidadNodos; i++)
        {
            Console::Write("Nodo " + i + ": ");
            Nodo^ temp = nodos[i]->siguiente;
            while (temp != nullptr)
            {
                Console::Write(temp->valor + " ");
                temp = temp->siguiente;
            }
            Console::WriteLine();
        }
    }
};
