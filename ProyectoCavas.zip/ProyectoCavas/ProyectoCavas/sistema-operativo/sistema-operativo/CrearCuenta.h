#pragma once
#include "Usuarios.h"
#include "con.h"
namespace sistemaoperativo {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::Collections::Generic;

    public ref class CrearCuenta : public System::Windows::Forms::Form
    {
    private:
        Form^ mainForm;  // Variable para almacenar la referencia al formulario anterior

    public:
        CrearCuenta(Form^ parentForm)
        {
            InitializeComponent();
            mainForm = parentForm;
        }

    protected:
        ~CrearCuenta()
        {
            if (components)
            {
                delete components;
            }
        }

    private: System::Windows::Forms::TextBox^ textBox2;
    protected:
    private: System::Windows::Forms::TextBox^ textBox1;
    private: System::Windows::Forms::Label^ label3;
    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::Label^ label1;

    private: System::Windows::Forms::Button^ button1;
    private: System::Windows::Forms::Label^ label4;
    private: System::Windows::Forms::ComboBox^ comboBox1;

    private:
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(CrearCuenta::typeid));
            this->textBox2 = (gcnew System::Windows::Forms::TextBox());
            this->textBox1 = (gcnew System::Windows::Forms::TextBox());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->button1 = (gcnew System::Windows::Forms::Button());
            this->label4 = (gcnew System::Windows::Forms::Label());
            this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
            this->SuspendLayout();
            // 
            // textBox2
            // 
            resources->ApplyResources(this->textBox2, L"textBox2");
            this->textBox2->Name = L"textBox2";
            // 
            // textBox1
            // 
            resources->ApplyResources(this->textBox1, L"textBox1");
            this->textBox1->Name = L"textBox1";
            // 
            // label3
            // 
            resources->ApplyResources(this->label3, L"label3");
            this->label3->ForeColor = System::Drawing::SystemColors::ControlLightLight;
            this->label3->Name = L"label3";
            // 
            // label2
            // 
            resources->ApplyResources(this->label2, L"label2");
            this->label2->ForeColor = System::Drawing::SystemColors::ControlLightLight;
            this->label2->Name = L"label2";
            // 
            // label1
            // 
            resources->ApplyResources(this->label1, L"label1");
            this->label1->ForeColor = System::Drawing::SystemColors::ControlLightLight;
            this->label1->Name = L"label1";
            // 
            // button1
            // 
            this->button1->BackColor = System::Drawing::SystemColors::ControlLightLight;
            resources->ApplyResources(this->button1, L"button1");
            this->button1->ForeColor = System::Drawing::Color::Black;
            this->button1->Name = L"button1";
            this->button1->UseVisualStyleBackColor = false;
            this->button1->Click += gcnew System::EventHandler(this, &CrearCuenta::button1_Click);
            // 
            // label4
            // 
            resources->ApplyResources(this->label4, L"label4");
            this->label4->ForeColor = System::Drawing::SystemColors::ControlLightLight;
            this->label4->Name = L"label4";
            // 
            // comboBox1
            // 
            this->comboBox1->FormattingEnabled = true;
            this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(3) {
                resources->GetString(L"comboBox1.Items"), resources->GetString(L"comboBox1.Items1"),
                    resources->GetString(L"comboBox1.Items2")
            });
            resources->ApplyResources(this->comboBox1, L"comboBox1");
            this->comboBox1->Name = L"comboBox1";
            // 
            // CrearCuenta
            // 
            resources->ApplyResources(this, L"$this");
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::MidnightBlue;
            this->Controls->Add(this->comboBox1);
            this->Controls->Add(this->label4);
            this->Controls->Add(this->textBox2);
            this->Controls->Add(this->textBox1);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->button1);
            this->Name = L"CrearCuenta";
            this->Load += gcnew System::EventHandler(this, &CrearCuenta::CrearCuenta_Load);
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

    private: System::Void CrearCuenta_Load(System::Object^ sender, System::EventArgs^ e) {
    
        comboBox1->SelectedIndex = 2; // This sets the default selection to "Alumno"

    }

    private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
        // Recoger los valores de los TextBox
        String^ nombreUsuario = textBox1->Text;
        String^ contrasena = textBox2->Text;
        String^ rol = comboBox1->SelectedItem->ToString(); // Obtener el rol seleccionado

        // Verificar si los campos est�n vac�os
        if (nombreUsuario->Length == 0 || contrasena->Length == 0 || rol->Length == 0) {
            MessageBox::Show("Por favor, ingrese todos los campos.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            return;
        }

        // Agregar el nuevo usuario a la lista est�tica de usuarios con el rol
        //suarios::AgregarUsuario(nombreUsuario, contrasena, rol);
        // Insertar en la base de datos
        bool resultado = ConexionDB::InsertarUsuario(nombreUsuario, contrasena, rol);

        if (resultado) {
          //  MessageBox::Show("Cuenta creada con �xito.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);

            // Limpiar los campos
            textBox1->Clear();
            textBox2->Clear();
            comboBox1->SelectedIndex = 2;
        }
        // Confirmar que el usuario ha sido creado
        MessageBox::Show("Cuenta creada con �xito.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
        this->Close();
        mainForm->Show();


    }


    };
}
