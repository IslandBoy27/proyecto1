#include "MainForm.h"  // Incluye el encabezado del formulario principal

using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]
void main(array<String^>^ args)
{
    Application::EnableVisualStyles(); // Activa los estilos visuales para la aplicaci�n
    Application::SetCompatibleTextRenderingDefault(false); // Configura el renderizado de texto para que sea compatible
    sistemaoperativo::MainForm form; // Crea una instancia del formulario `MainForm` en el espacio de nombres `sistemaoperativo`
    Application::Run(% form); // Ejecuta la aplicaci�n con `form` como formulario principal
}
