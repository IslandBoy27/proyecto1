#pragma once

public ref class Nodo
{
public:
    int valor; // Valor del nodo (en este caso, un n�mero)
    Nodo^ siguiente; // Puntero al siguiente nodo (para lista o grafos)
    Nodo^ hijoIzq; // Puntero al hijo izquierdo (para �rbol binario)
    Nodo^ hijoDer; // Puntero al hijo derecho (para �rbol binario)

    // Constructor
    Nodo(int valor)
    {
        this->valor = valor;
        this->siguiente = nullptr;
        this->hijoIzq = nullptr;
        this->hijoDer = nullptr;
    }
};
