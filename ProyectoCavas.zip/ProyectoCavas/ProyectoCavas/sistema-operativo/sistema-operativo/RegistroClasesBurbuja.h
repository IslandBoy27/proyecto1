#pragma once
ref class RegistroClasesBurbuja
{
};

