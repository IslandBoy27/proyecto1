#pragma once
using namespace System::Data;
using namespace System;
using namespace System::Data::OleDb;
using namespace System::Windows::Forms;

public ref class Usuario
 

{
public:
    String^ Cuenta;
    String^ Contrase�a;
    String^ Rol;

};

ref class ConexionDB
{
public:
    static String^ connectionString =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Data\\Data.accdb";

    // M�todo para insertar un usuario
    static bool InsertarUsuario(String^ cuenta, String^ contrase�a, String^ rol)
    {
        try
        {
            // Crear la conexi�n a la base de datos
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            // Crear la consulta SQL para insertar un usuario
            String^ query = "INSERT INTO Usuarios (cuenta, contrase�a, rol) VALUES (?, ?, ?)";

            // Crear el comando con la consulta y la conexi�n
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

            // Agregar los par�metros para evitar inyecci�n SQL
            cmd->Parameters->AddWithValue("?", cuenta);
            cmd->Parameters->AddWithValue("?", contrase�a);
            cmd->Parameters->AddWithValue("?", rol);

            // Ejecutar la consulta
            int filasAfectadas = cmd->ExecuteNonQuery();

            // Cerrar la conexi�n
            conn->Close();

            return filasAfectadas > 0; // Retorna true si se insert� correctamente
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false; // Retorna false si hubo un error
        }
    }
    // M�todo para verificar si el usuario existe con la contrase�a correcta
    static bool VerificarUsuario1(String^ cuenta, String^ contrase�a)
    {
        try
        {
            // Crear la conexi�n a la base de datos
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            // Crear la consulta SQL para verificar el usuario
            String^ query = "SELECT COUNT(*) FROM Usuarios WHERE cuenta = ? AND contrase�a = ?";

            // Crear el comando con la consulta y la conexi�n
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

            // Agregar los par�metros para evitar inyecci�n SQL
            cmd->Parameters->AddWithValue("?", cuenta);
            cmd->Parameters->AddWithValue("?", contrase�a);

            // Ejecutar la consulta y obtener el resultado
            int count = Convert::ToInt32(cmd->ExecuteScalar());

            // Cerrar la conexi�n
            conn->Close();

            return count > 0; // Retorna true si encontr� un usuario
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false; // Retorna false si hubo un error
        }
    }
    // M�todo para buscar un usuario por su ID
    static Usuario^ BuscarUsuarioPorId(int id)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();
            String^ query = "SELECT cuenta, contrase�a, rol FROM Usuarios WHERE id = ?";
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);
            cmd->Parameters->AddWithValue("?", id);

            // Ejecutar la consulta y obtener los datos
            OleDbDataReader^ reader = cmd->ExecuteReader();

            if (reader->Read()) // Si encuentra un usuario
            {
                Usuario^ usuario = gcnew Usuario();
                usuario->Cuenta = reader->GetString(0); // Primer columna: cuenta
                usuario->Contrase�a = reader->GetString(1); // Segunda columna: contrase�a
                usuario->Rol = reader->GetString(2); // Tercera columna: rol
                conn->Close();
                return usuario; // Retorna el objeto Usuario
            }

            conn->Close();
            return nullptr; // Retorna nullptr si no encontr� al usuario
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return nullptr; // Retorna nullptr si hubo un error
        }
    }

    // M�todo para eliminar un usuario por su ID
    static bool EliminarUsuario(int id)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();
            String^ query = "DELETE FROM Usuarios WHERE id = ?";
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);
            cmd->Parameters->AddWithValue("?", id);
            int filasAfectadas = cmd->ExecuteNonQuery();
            conn->Close();
            return filasAfectadas > 0;
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false; 
        }
    }
    // M�todo para editar un usuario por su ID
    static bool EditarUsuario(int id, String^ nuevaCuenta, String^ nuevaContrase�a, String^ nuevoRol)
    {
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();
            String^ query = "UPDATE Usuarios SET cuenta = ?, contrase�a = ?, rol = ? WHERE id = ?";
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);
            cmd->Parameters->AddWithValue("?", nuevaCuenta);
            cmd->Parameters->AddWithValue("?", nuevaContrase�a);
            cmd->Parameters->AddWithValue("?", nuevoRol);
            cmd->Parameters->AddWithValue("?", id);
            int filasAfectadas = cmd->ExecuteNonQuery();
            conn->Close();
            return filasAfectadas > 0;
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            return false; 
        }
    }

   // M�todo para obtener todos los usuarios con rol "Alumno" de la tabla Usuarios
    static DataTable^ ObtenerUsuariosAlumno()
    {
        DataTable^ dt = gcnew DataTable(); // Definir dt antes de su uso
        try
        {
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();
            // Se filtran solo los usuarios cuyo rol es "Alumno"
            String^ query = "SELECT * FROM Usuarios WHERE rol = 'Alumno'";
            OleDbDataAdapter^ adapter = gcnew OleDbDataAdapter(query, conn);
            adapter->Fill(dt);
            conn->Close();
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
        }
        return dt;
    }
    static void LlenarCheckedListBoxAlumnos(CheckedListBox^ checkedListBox1)
    {
        try
        {
            // Crear conexi�n a la base de datos
            OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
            conn->Open();

            // Consulta SQL para obtener solo los usuarios con rol "Alumno"
            String^ query = "SELECT cuenta FROM Usuarios WHERE rol = 'Alumno'";
            OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

            // Limpiar la lista antes de agregar nuevos elementos
            checkedListBox1->Items->Clear();

            // Ejecutar la consulta y leer los resultados
            OleDbDataReader^ reader = cmd->ExecuteReader();
            int count = 0; // Contador de usuarios encontrados

            while (reader->Read())
            {
                String^ cuenta = reader["cuenta"]->ToString();
                checkedListBox1->Items->Add(cuenta);
                count++; // Incrementar el contador
            }

            reader->Close();
            conn->Close();

            // Mostrar un MessageBox si se encontraron usuarios
            if (count > 0)
            {
                //MessageBox::Show("Se encontraron " + count + " usuarios.", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
            }
            else
            {
                MessageBox::Show("No se encontraron usuarios con rol 'Alumno'.", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
            }
        }
        catch (Exception^ ex)
        {
            Console::WriteLine("Error: " + ex->Message);
            MessageBox::Show("Ocurri� un error al intentar obtener los usuarios.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
        }
    }

static void LlenarComboBoxMaestros(ComboBox^ comboBox)
{
    try
    {
        // Crear la conexi�n a la base de datos
        OleDbConnection^ conn = gcnew OleDbConnection(connectionString);
        conn->Open();

        // Consulta SQL para obtener las cuentas de los maestros
        String^ query = "SELECT nombre FROM Maestros";
        OleDbCommand^ cmd = gcnew OleDbCommand(query, conn);

        // Limpiar los elementos actuales del ComboBox
        comboBox->Items->Clear();

        // Ejecutar la consulta y llenar el ComboBox con los resultados
        OleDbDataReader^ reader = cmd->ExecuteReader();
        int count = 0;

        while (reader->Read())
        {
            String^ cuenta = reader["nombre"]->ToString();
            comboBox->Items->Add(cuenta);
            count++;
        }

        reader->Close();

        // Verificar si no se encontraron datos
        if (count == 0)
        {
            MessageBox::Show("No se encontraron maestros.", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
        }

        conn->Close();
    }
    catch (Exception^ ex)
    {
        Console::WriteLine("Error: " + ex->Message);
        MessageBox::Show("Ocurri� un error al intentar obtener los maestros.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
}






};
